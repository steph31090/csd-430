<%--
  Stephanie Ramos
  February 6, 2026
  Module 6 Project Part 1
  
  Purpose: Show a dropdown menu of movie_id values from the database.
--%>

<%@ page import="beans.MovieBean,java.util.List" %>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Movie Lookup</title>
</head>
<body>
  <h1>Movie Record Lookup</h1>
  <p>Choose a movie ID from the dropdown menu and click Submit to view the movie details. </p>

  <%
  	
 	// Connect to the database using the Javabean and retrieve movie IDs
    MovieBean bean = new MovieBean();
    List<Integer> ids = null;
    String errorMsg = null;

    try {
        ids = bean.getAllMovieIds();
    } catch (Exception e) {
        errorMsg = e.getMessage();
    }
  %>

  <% if (errorMsg != null) { %>
    <p><strong>Error:</strong> <%= errorMsg %></p>
  <% } else { %>
  
  	<!-- Allows user to select a movie ID and submit the form to view movie details -->
    <form action="viewMovie.jsp" method="post">
      <label for="movieId">Movie ID:</label>
      <select name="movieId" id="movieId">
        <% for (Integer id : ids) { %>
          <option value="<%= id %>"><%= id %></option>
        <% } %>
      </select>
      <button type="submit">Submit</button>
    </form>
  <% } %>

	<!-- Navigation link back to the project index page -->
  <p><a href="index.jsp">Back to Index</a></p>
</body>
</html>
