<%@ page import="beans.MovieBean,java.util.List" %>
<%--
  Stephanie Ramos
  CSD430
  Module 7 Assignment:
  Project Part 2
  
  Purpose: Insert a new movie record and display all records in a table.
--%>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Create Movie Result</title>
</head>
<body>

<h1>Create Movie Result</h1>

<p>This page adds a new movie record and displays all movie records.</p>

<%
    // Read user input and insert record using the JavaBean
    String title = request.getParameter("title");
    String genre = request.getParameter("genre");
    String releaseYearStr = request.getParameter("releaseYear");
    String director = request.getParameter("director");

    String errorMsg = null;
    List<MovieBean> movies = null;

    try {
        int releaseYear = Integer.parseInt(releaseYearStr);

        MovieBean bean = new MovieBean();
        bean.addMovie(title, genre, releaseYear, director);

        // Retrieve all records for display
        movies = bean.getAllMovies();

    } catch (Exception e) {
        errorMsg = e.getMessage();
    }
%>

<% if (errorMsg != null) { %>
  <p><strong>Error:</strong> <%= errorMsg %></p>
<% } else { %>

  <p><strong>Status:</strong> Movie record added.</p>

  <table border="1">
    <thead>
      <tr>
        <th>Movie ID</th>
        <th>Title</th>
        <th>Genre</th>
        <th>Release Year</th>
        <th>Director</th>
      </tr>
    </thead>
    <tbody>
      <% for (MovieBean m : movies) { %>
        <tr>
          <td><%= m.getMovieId() %></td>
          <td><%= m.getTitle() %></td>
          <td><%= m.getGenre() %></td>
          <td><%= m.getReleaseYear() %></td>
          <td><%= m.getDirector() %></td>
        </tr>
      <% } %>
    </tbody>
  </table>

<% } %>

<p>
  <a href="addMovie.jsp">Add Another Movie</a> |
  <a href="index.jsp">Back to Index</a>
</p>

</body>
</html>
