<%@ page import="beans.MovieBean" %>
<%--
  Stephanie Ramos
  CSD430
  Module 8:
  Project Part 3 UPDATE

  Purpose: Update a movie record and display the updated record in a table.
--%>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Updated Movie Record</title>
  <style>
    body { font-family: Arial; margin: 20px; }
    table { border-collapse: collapse; margin-top: 12px; }
    th, td { border: 1px solid #ccc; padding: 8px 10px; }
    th { background: #f2f2f2; }
  </style>
</head>
<body>

<h1>Updated Movie Record</h1>
<p>This is the current updated record for the selected movie.</p>

<%
    // Read edited values and update the record using the JavaBean
    String movieIdStr = request.getParameter("movieId");
    String title = request.getParameter("title");
    String genre = request.getParameter("genre");
    String releaseYearStr = request.getParameter("releaseYear");
    String director = request.getParameter("director");

    String errorMsg = null;
    MovieBean bean = new MovieBean();

    try {
        int movieId = Integer.parseInt(movieIdStr);
        int releaseYear = Integer.parseInt(releaseYearStr);

        bean.updateMovie(movieId, title, genre, releaseYear, director);

        // Reload the updated record for display
        bean.loadById(movieId);

    } catch (Exception e) {
        errorMsg = e.getMessage();
    }
%>

<% if (errorMsg != null) { %>
  <p><strong>Error:</strong> <%= errorMsg %></p>
<% } else { %>

  <table>
    <thead>
      <tr>
        <th>Movie ID</th>
        <th>Title</th>
        <th>Genre</th>
        <th>Release Year</th>
        <th>Director</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><%= bean.getMovieId() %></td>
        <td><%= bean.getTitle() %></td>
        <td><%= bean.getGenre() %></td>
        <td><%= bean.getReleaseYear() %></td>
        <td><%= bean.getDirector() %></td>
      </tr>
    </tbody>
  </table>

<% } %>

<p>
  <a href="updateSelect.jsp">Update Another Movie</a> |
  <a href="index.jsp">Back to Index</a>
</p>

</body>
</html>