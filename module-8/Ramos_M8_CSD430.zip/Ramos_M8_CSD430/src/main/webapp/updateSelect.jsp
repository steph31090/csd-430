<%@ page import="beans.MovieBean,java.util.List" %>
<%--
  Stephanie Ramos
  CSD430
  Module 8:
  Project Part 3 UPDATE
  
  Purpose: Select a movie_id to update.
--%>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Update Movie Record</title>
  <style>
    body { font-family: Arial; margin: 20px; }
    .box { max-width: 600px; padding: 16px; border: 1px solid #ccc; }
    label { display: inline-block; width: 90px; }
    select, button { padding: 6px; }
  </style>
</head>
<body>

<h1>Update Movie Record</h1>
<p>Select a movie ID and click Submit to update the record.</p>

<%
    // Retrieve all movie IDs for the dropdown
    MovieBean bean = new MovieBean();
    List<Integer> ids = null;
    String errorMsg = null;

    try {
        ids = bean.getAllMovieIds();
    } catch (Exception e) {
        errorMsg = e.getMessage();
    }
%>

<div class="box">
<% if (errorMsg != null) { %>
  <p><strong>Error:</strong> <%= errorMsg %></p>
<% } else { %>

  <form action="updateForm.jsp" method="post">
    <label for="movieId">Movie ID:</label>
    <select name="movieId" id="movieId">
      <% for (Integer id : ids) { %>
        <option value="<%= id %>"><%= id %></option>
      <% } %>
    </select>
    <button type="submit">Submit</button>
  </form>

<% } %>
</div>

<p><a href="index.jsp">Back to Index</a></p>

</body>
</html>