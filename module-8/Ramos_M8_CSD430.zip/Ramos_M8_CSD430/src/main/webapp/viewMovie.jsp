<%@ page import="beans.MovieBean" %>
<%--
  Stephanie Ramos
  February 6, 2026
  Module 6 Project Part 1 READ
  
  Purpose: Display the selected movie record in an HTML table.
--%>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Movie Record</title>
</head>
<body>

<h1>Movie Record</h1>
<p>Movie details shown below include:</p>
<ul>
  <li>Movie ID</li>
  <li>Title</li>
  <li>Genre</li>
  <li>Release Year</li>
  <li>Director</li>
</ul>

<%
	// Retrieve the selected movie ID and load the record using Javabean
    String movieIdStr = request.getParameter("movieId");
    String errorMsg = null;
    boolean found = false;

    MovieBean bean = new MovieBean();

    if (movieIdStr == null || movieIdStr.trim().isEmpty()) {
        errorMsg = "No movie ID was selected. Please go back and choose one.";
    } else {
        try {
            int id = Integer.parseInt(movieIdStr);
            found = bean.loadById(id);

            if (!found) {
                errorMsg = "No record found for movie ID: " + id;
            }
        } catch (Exception e) {
            errorMsg = e.getMessage();
        }
    }
%>

<% if (errorMsg != null) { %>
    <p><strong>Error:</strong> <%= errorMsg %></p>
<% } else { %>

	<!-- Display the selected movie record in an HTML table -->
    <table border="1">
        <thead>
            <tr>
                <th>Movie ID</th>
                <th>Title</th>
                <th>Genre</th>
                <th>Release Year</th>
                <th>Director</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><%= bean.getMovieId() %></td>
                <td><%= bean.getTitle() %></td>
                <td><%= bean.getGenre() %></td>
                <td><%= bean.getReleaseYear() %></td>
                <td><%= bean.getDirector() %></td>
            </tr>
        </tbody>
    </table>
<% } %>

<!-- Navigation links to return to index or Movie Record Lookup Page -->
<p><a href="updateSelect.jsp">Update a Movie</a>
<p><a href="selectMovie.jsp">Back to Movie Record Lookup Page</a></p>
<p><a href="index.jsp">Back to Index</a></p>

</body>
</html>
