<%--
	Stephanie Ramos
	February 6, 2026
	Module 5-9 Project:
	CRUD- READ, CREATE, UPDATE, DELETE, JDBC and JavaBeans
	
	Purpose: Index Page linking to jsp files.
 --%>


<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Module 5 & 6 Assignment: Project Part 1</title>
</head>
<body>
	<h1>CSD430 Project</h1>
	
	<h2>Movies Database</h2>
	<p><a href="selectMovie.jsp">Movie Record Lookup</a></p>
	
	<h2>Add Movie Record</h2>
	<p><a href="addMovie.jsp">Click here to add a movie record</a></p>
	
	<h2>Update Movie Record</h2>
	<p><a href="updateSelect.jsp">Click here to update a movie record</a></p>

</body>
</html>