<%@ page import="beans.MovieBean" %>
<%--
  Stephanie Ramos
  CSD430
  Module 7 Assignment:
  Project Part 2
  
  Purpose: Collect user input to add a new movie record.
--%>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Add Movie Record</title>
</head>
<body>

<h1>Add Movie Record</h1>

<p>Enter movie information and click Submit to add a new record.</p>

<form action="addMovieResult.jsp" method="post">
  <p>
    <label for="title">Title:</label>
    <input type="text" name="title" id="title" required>
  </p>

  <p>
    <label for="genre">Genre:</label>
    <input type="text" name="genre" id="genre" required>
  </p>

  <p>
    <label for="releaseYear">Release Year:</label>
    <input type="number" name="releaseYear" id="releaseYear" required>
  </p>

  <p>
    <label for="director">Director:</label>
    <input type="text" name="director" id="director" required>
  </p>

  <button type="submit">Submit</button>
</form>

<p><a href="index.jsp">Back to Index</a></p>

</body>
</html>
