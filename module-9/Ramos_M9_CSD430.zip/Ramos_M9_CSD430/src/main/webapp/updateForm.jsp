<%@ page import="beans.MovieBean" %>
<%--
  Stephanie Ramos
  CSD430
  Module 8:
  Project Part 3 UPDATE

  Purpose: Display the selected record in input fields for updating.
--%>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Edit Movie Record</title>
  <style>
    body { font-family: Arial; margin: 20px; }
    .box { max-width: 650px; padding: 16px; border: 1px solid #ccc; }
    .row { margin-bottom: 10px; }
    label { display: inline-block; width: 110px; }
    input { padding: 6px; width: 320px; }
    .key { font-weight: bold; }
    button { padding: 8px 12px; }
  </style>
</head>
<body>

<h1>Edit Movie Record</h1>
<p>Update the fields below and click Submit to save changes.</p>

<%
    // Load the record the user selected
    String movieIdStr = request.getParameter("movieId");
    String errorMsg = null;

    MovieBean bean = new MovieBean();
    boolean found = false;

    try {
        int movieId = Integer.parseInt(movieIdStr);
        found = bean.loadById(movieId);

        if (!found) {
            errorMsg = "There is no record found for the selected movie ID.";
        }
    } catch (Exception e) {
        errorMsg = e.getMessage();
    }
%>

<div class="box">
<% if (errorMsg != null) { %>
  <p><strong>Error:</strong> <%= errorMsg %></p>
<% } else { %>

  <form action="updateResult.jsp" method="post">

    <div class="row">
      <label>Movie ID:</label>
      <span class="key"><%= bean.getMovieId() %></span>
    </div>

    <input type="hidden" name="movieId" value="<%= bean.getMovieId() %>">

    <div class="row">
      <label for="title">Title:</label>
      <input type="text" name="title" id="title" value="<%= bean.getTitle() %>" required>
    </div>

    <div class="row">
      <label for="genre">Genre:</label>
      <input type="text" name="genre" id="genre" value="<%= bean.getGenre() %>" required>
    </div>

    <div class="row">
      <label for="releaseYear">Release Year:</label>
      <input type="number" name="releaseYear" id="releaseYear" value="<%= bean.getReleaseYear() %>" required>
    </div>

    <div class="row">
      <label for="director">Director:</label>
      <input type="text" name="director" id="director" value="<%= bean.getDirector() %>" required>
    </div>

    <button type="submit">Submit</button>
  </form>

<% } %>
</div>

<p>
  <a href="updateSelect.jsp">Return to Update Movie</a> |
  <a href="index.jsp">Back to Index</a>
</p>

</body>
</html>