<%@ page import="beans.MovieBean,java.util.List" %>
<%--
  Stephanie Ramos
  CSD430
  Project Part 4 DELETE
  March 1, 2026
  
  Purpose: Display all movie records and allow the user to delete a record by movie ID.
--%>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Delete Movie Record</title>
</head>
<body>

<h1>Delete Movie Record</h1>

<p>
  This page displays the current database containing the movie records.
  To remove a record select the MovieID from the drop down menu and select Delete.
</p>

<%
   
    String movieIdStr = request.getParameter("movieId");
    String errorMsg = null;

    MovieBean bean = new MovieBean();

    try {
        if (movieIdStr != null && !movieIdStr.trim().isEmpty()) {
            int movieId = Integer.parseInt(movieIdStr);
            bean.deleteMovie(movieId);
        }
    } catch (Exception e) {
        errorMsg = e.getMessage();
    }

    
    List<MovieBean> movies = null;
    List<Integer> ids = null;

    try {
        movies = bean.getAllMovies();
        ids = bean.getAllMovieIds();
    } catch (Exception e) {
        errorMsg = e.getMessage();
    }
%>

<% if (errorMsg != null) { %>
  <p><strong>Error:</strong> <%= errorMsg %></p>
<% } %>

<!-- Dropdown for selecting a record to delete -->
<form action="deleteMovie.jsp" method="post">
  <label for="movieId">Movie ID:</label>
  <select name="movieId" id="movieId">
    <% if (ids != null) { 
         for (Integer id : ids) { %>
          <option value="<%= id %>"><%= id %></option>
    <%   } 
       } %>
  </select>
  <button type="submit">Delete</button>
</form>

<!-- Display all records in an HTML table -->
<table border="1">
  <thead>
    <tr>
      <th>Movie ID</th>
      <th>Title</th>
      <th>Genre</th>
      <th>Release Year</th>
      <th>Director</th>
    </tr>
  </thead>
  <tbody>
    <% if (movies != null) {
         for (MovieBean m : movies) { %>
          <tr>
            <td><%= m.getMovieId() %></td>
            <td><%= m.getTitle() %></td>
            <td><%= m.getGenre() %></td>
            <td><%= m.getReleaseYear() %></td>
            <td><%= m.getDirector() %></td>
          </tr>
    <%   }
       } %>
  </tbody>
</table>

<p>
  <a href="index.jsp">Back to Index</a> |
  <a href="addMovie.jsp">Add a Movie</a> |
  <a href="updateSelect.jsp">Update a Movie</a>
</p>

</body>
</html>