package beans;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MovieBean implements Serializable {

    private static final long serialVersionUID = 1L;

    // fields to match the database table columns
    private int movieId;
    private String title;
    private String genre;
    private int releaseYear;
    private String director;

    // Database connection settings
    private static final String DB_URL =
            "jdbc:mysql://localhost:3306/CSD430?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String DB_USER = "student1";
    private static final String DB_PASS = "pass";

    // Getter methods to display the values
    public MovieBean() {
    }

    public int getMovieId() {
        return movieId;
    }

    public String getTitle() {
        return title;
    }

    public String getGenre() {
        return genre;
    }

    public int getReleaseYear() {
        return releaseYear;
    }

    public String getDirector() {
        return director;
    }

    // Creates database connection, and loads the MySQL JDBC driver.
    private Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("MySQL JDBC Driver not found. Check WEB-INF/lib.", e);
        }
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
    }

    // Retrieves all movies_id values from the database
    public List<Integer> getAllMovieIds() throws SQLException {
        List<Integer> ids = new ArrayList<>();
        String sql = "SELECT movie_id FROM stephanie_movies_data ORDER BY movie_id";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                ids.add(rs.getInt("movie_id"));
            }
        }
        return ids;
    }

    // Loads selected movie record
    public boolean loadById(int id) throws SQLException {
        String sql = "SELECT movie_id, title, genre, release_year, director " +
                     "FROM stephanie_movies_data WHERE movie_id = ?";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    movieId = rs.getInt("movie_id");
                    title = rs.getString("title");
                    genre = rs.getString("genre");
                    releaseYear = rs.getInt("release_year");
                    director = rs.getString("director");
                    return true;
                }
            }
        }
        return false;
    }
}
