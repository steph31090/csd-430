SELECT user, host, plugin
FROM mysql.user
WHERE user = 'student1';
CREATE DATABASE CSD430;
CREATE USER 'student1'@'localhost' IDENTIFIED BY 'pass';
Grant all privileges on csd430.* to 'student1'@'localhost';
flush privileges;
select user, host
from mysql.user
where user = 'student1';
use csd430;
create table stephanie_movies_data (
	movie_id int auto_increment primary key,
    title varchar(100) not null,
    genre varchar(50) not null,
    release_year int not null,
    director varchar(100) not null
);

insert into stephanie_movies_data (title, genre, release_year, director) values
('The Notebook', 'Romance', 2004, 'Nick Cassavetes'),
('The Housemaid', 'Thriller', 2025, 'Paul Feig'),
('The Conjuring', 'Horror', 2013, 'James Wan'),
('Gone Girl', 'Thriller', 2014, 'David Fincher'),
('Sinners', 'Horror', 2025, ' Ryan Coogler'),
('Dracula', 'Horror', 2025, 'Luc Besson'),
('Presence', 'Thriller', 2024, 'Steven Soderbergh'),
('The Devil Wears Prada', 'Comedy', 2006, 'David Frankel'),
('Insidious', 'Horror', 2010, 'James Wan'),
('What Happens in Vegas', 'Romantic Comedy', 2008, 'Tom Vaughn');

select * from stephanie_movies_data;






